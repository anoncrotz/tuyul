<?

$email = "xxxxxxxx@gmail.com";
$password = "xxxxxx";
$PHPSESSID = "xxxxxxx";
$cfduid = "xxxxxxx";