<?

$btcsurfsession = "xxxxxxx";
$xsrftoken = "xxxxxxxxx";